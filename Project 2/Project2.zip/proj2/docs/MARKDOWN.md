CDSVReader utilizes the following files:
    include/DSVReader.h    include/DataSource.h
    src/DSVReader.cpp

This class reads individual rows of a file. Ideally, this is used in conjunction with ifstream and read the line by using getline()