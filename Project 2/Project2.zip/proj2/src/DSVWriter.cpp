#include <iostream>
#include <memory>
#include "../include/DSVWriter.h"
using namespace std;

struct CDSVWriter::SImplementation{
    shared_ptr<CDataSink> Sink;
    char Delimiter;
    bool QuoteAll;

    SImplementation(shared_ptr<CDataSink> outputSink, char delimiter, bool quoteAll) : Sink(move(outputSink)), Delimiter(delimiter),
                    QuoteAll(quoteAll){}

    
};






// class CDSVWriter{
//     private:
//         struct SImplementation;
//         std::unique_ptr<SImplementation> DImplementation;

//     public:
//         CDSVWriter(std::shared_ptr< CDataSink > sink, char delimiter, bool quoteall = false);
//         ~CDSVWriter();

//         bool WriteRow(const std::vector<std::string> &row);
// };